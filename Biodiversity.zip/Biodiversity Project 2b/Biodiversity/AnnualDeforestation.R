# Load necessary library
library(ggplot2)
library(maps)
library(scales)

# Load deforestation data
df <- read.csv("~/R/Biodiversity/Data/annual-deforestation.csv")

# Line plot of deforestation over time
ggplot(df, aes(x = Year, y = Deforestation)) +  # specify data and aesthetics
  geom_line() +  # add a line layer
  labs(title = "Deforestation over Time", x = "Year", y = "Deforestation (sq. km)")  # customize plot titles and labels

# Bar chart of deforestation by country in 2010
df_2010 <- df[df$Year == 2010,]  # subset data for 2010 only
ggplot(df_2010, aes(x = Entity, y = Deforestation)) +  # specify data and aesthetics
  geom_bar(stat = "identity") +  # add a bar layer
  labs(title = "Deforestation by Country in 2010", x = "Country", y = "Deforestation (sq. km)")  # customize plot titles and labels

# Plot deforestation data over time for different countries/regions
ggplot(df, aes(x = Year, y = Deforestation, color = Entity)) +  # specify data and aesthetics
  geom_line() +  # add a line layer
  scale_x_continuous(breaks = seq(1990, 2015, 5)) +  # customize x-axis breaks
  labs(x = "Year", y = "Deforestation (sq km)", color = "Country/Region") +  # customize axis labels
  theme_classic()  # apply a classic theme

# Plot bubble chart
ggplot(df, aes(x = Year, y = Entity, size = Deforestation)) +
  geom_point(alpha = 0.7) +
  scale_x_continuous(breaks = seq(1990, 2015, 5)) +
  scale_size(range = c(1, 10), breaks = seq(0, 10000, by = 2000), labels = comma) +
  labs(x = "Year", y = "Country/Region", size = "Deforestation (sq km)") +
  theme_classic()

# Subset data for a single year (2015)
df_2015 <- subset(df, Year == 2015)
df_Brazil <- subset(df, Entity == "Brazil")

# Create bubble chart
ggplot(df_Brazil, aes(x = Year, y = Entity, size = Deforestation))  +
  geom_point(alpha = 0.7) +
  scale_size(range = c(2, 20)) +
  labs(x = "Year", y = "Country/Region", size = "Deforestation (sq km)") +
  theme_classic()

# Load world map data
world_map <- map_data("world")

# Plot world map
ggplot(world_map, aes(x = long, y = lat, group = group)) +
  geom_polygon(fill = "white", color = "black") +
  coord_equal()

# Load the data
embodied_emissions <- read.csv("~/R/Biodiversity/Data/co2-deforestation-for-food.csv")

# Create the ggplot
ggplot(embodied_emissions, aes(x = Entity, y = total_embodied_emissions)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  xlab("Country") +
  ylab("Total Embodied Emissions (tonnes CO2e)") +
  ggtitle("Total Embodied Emissions by Country in 2013")


#Dot Plot
ggplot(embodied_emissions, aes(x = total_embodied_emissions, y = Entity)) +
  geom_point() +
  xlab("Total Embodied Emissions") +
  ylab("Country") +
  ggtitle("Total Embodied Emissions by Country in 2013") +
  theme(axis.text.y = element_text(size = 8))
