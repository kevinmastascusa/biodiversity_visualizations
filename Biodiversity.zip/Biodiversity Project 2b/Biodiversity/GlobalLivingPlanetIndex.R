library(ggplot2)
library(dplyr)

data <- read.csv("~/R/Biodiversity/Data/global-living-planet-index-2.csv")

ggplot(data, aes(x=Year, y=living_planet_index_average, color = Entity)) + 
  geom_point() + 
  labs(title = "Global Living Planet Index", x = "Year", y = "Index")