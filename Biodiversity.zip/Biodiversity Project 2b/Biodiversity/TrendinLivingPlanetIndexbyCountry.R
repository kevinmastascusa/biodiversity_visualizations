library(ggplot2)
library(dplyr)

data <- read.csv("~/R/Biodiversity/Data/global-living-planet-index-2.csv")

ggplot(data, aes(x=Year, y=living_planet_index_average, color = Entity)) + 
  geom_point() + 
  geom_smooth(method="lm", se=FALSE) +
  scale_color_brewer(palette="Dark2") +
  facet_wrap(~Entity, ncol=3) +
  labs(title = "Global Living Planet Index", x = "Year", y = "Index", 
       color = "Entity Type", subtitle = "Trend in Living Planet Index by Country") + 
  theme_minimal()
