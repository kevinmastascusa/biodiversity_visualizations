library(ggplot2)

data(ghg_emissions)

# Convert data to long format
library(tidyr)
ghg_emissions_long <- pivot_longer(ghg_emissions, 
                                   cols = Agriculture:Other.fuel.combustion, 
                                   names_to = "Sector", 
                                   values_to = "Emissions")

# Plot stacked bar chart
ggplot(ghg_emissions_long, aes(x = Year, y = Emissions, fill = Sector)) + 
  geom_col() +
  scale_y_continuous(labels = scales::unit_format(unit = "tCO2e", scale = 1e-12)) +
  labs(title = "Global Greenhouse Gas Emissions by Sector",
       x = "Year",
       y = "Emissions (tCO2e)",
       fill = "Sector") +
  theme_minimal() +
  theme(legend.position = "bottom")

