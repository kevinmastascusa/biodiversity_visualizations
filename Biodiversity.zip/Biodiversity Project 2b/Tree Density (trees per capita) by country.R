library(ggplot2)

# Read data
tree_density <- read.csv("~/Bio/trees-per-capita.csv")

# Get world map polygons
world_map <- map_data("world")

# Join data
map_data <- merge(world_map, tree_density, by.x = "region", by.y = "Entity", all.x = TRUE)

# Create ggplot object
cloro_map <- ggplot(map_data, aes(x = long, y = lat, group = group, fill = `Tree.density..trees.per.capita.`)) +
  geom_polygon() +
  scale_fill_gradient2(low = "white", mid = "green", high = "darkgreen", midpoint = 30000) +
  labs(title = "Tree Density (trees per capita) by Country", fill = "Trees per Capita") +
  theme_bw()

cloro_map + geom_polygon(data = world_map, aes(x = long, y = lat, group = group), color = "black", fill = NA)