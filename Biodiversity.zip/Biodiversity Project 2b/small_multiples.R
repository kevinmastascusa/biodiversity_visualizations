library(tidyverse)
library(tidytuesdayR)

tt <- tt_load("2021-04-06")

tidy_brazil_loss <- function(variable) {
  tt$brazil_loss %>%
    select(year, variable) %>%
    mutate(cause = as.character(variable)) %>%
    select(year, cause, variable) %>%
    rename("loss" = variable)
}


variable_names <- colnames(tt$brazil_loss)[4:14]
tidy_brazil_list <- map(variable_names, tidy_brazil_loss)
tidy_brazil <- map_df(tidy_brazil_list, rbind)
tidy_brazil$cause <- as.factor(tidy_brazil$cause)
levels(tidy_brazil$cause)

levels(tidy_brazil$cause) <- c(
  "Commercial crops",
  "Fire loss",
  "Flooding due to dams",
  "Mining",
  "Natural disturbances",
  "Infrastructure (not roads)",
  "Pasture for livestock",
  "Roads",
  "Logging for lumber",
  "Small scale clearing",
  "Tree plantations"
)

tidy_brazil

net_forest_max <- tt$forest %>%
  filter(entity != "World") %>%
  group_by(entity) %>%
  summarise(total = sum(net_forest_conversion)) %>%
  slice_max(total, n = 6)

# Getting the six countries with the lowest net forest conversion
net_forest_min <- tt$forest %>%
  filter(entity != "World") %>%
  group_by(entity) %>%
  summarise(total = sum(net_forest_conversion)) %>%
  slice_min(total, n = 6)

# Binding the objects with the six highest and six lowest net forest conversions
net_forest_countries <- rbind(net_forest_max, net_forest_min)

# Plotting the causes of deforestation in Brazil
tidy_brazil %>%
  ggplot(aes(year, loss, colour = cause)) +
  geom_line(size = 0.8) +
  geom_hline(yintercept = 10000,
             linetype = 2,
             size = 0.5) +
  facet_wrap( ~ cause, scales = "free") +
  theme_gray() +
  guides(colour = FALSE) +
  labs(
    y = "Forest loss (hectares)",
    x = "Time",
    title = "Forest loss due to different causes in Brazil",
    subtitle = "Dashed line added at 10,000 hectares for perspective"
  )


# Plotting net change in forest area across different countries
tt$forest %>%
  filter(entity %in% net_forest_countries$entity) %>%
  select(entity, year, net_forest_conversion) %>%
  ggplot(aes(year, net_forest_conversion, colour = entity)) +
  geom_line(size = 0.9) +
  geom_hline(yintercept = 0) +
  geom_hline(
    yintercept = 250000,
    linetype = 2,
    colour = "green",
    size = 0.4
  ) +
  geom_hline(
    yintercept = -250000,
    linetype = 2,
    colour = "red",
    size = 0.4
  ) +
  facet_wrap( ~ entity, scales = "free") +
  theme_dark() +
  guides(colour = FALSE) +
  labs(
    y = "Net forest conversion (hectares)",
    x = "Time",
    title = "Countries with highest and lowest net changes in forest area",
    subtitle = "Dashed lines at +250,000 hectares (green) and -250,000 hectares (red)"
  )